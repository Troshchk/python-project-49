#!/usr/bin/env python3

from ..games.calc_module import play_calculator


def main():
    play_calculator()


if __name__ == "__main__":
    main()
