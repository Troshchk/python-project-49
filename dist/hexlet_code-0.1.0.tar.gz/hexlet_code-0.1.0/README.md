### Hexlet tests and linter status:
[![Actions Status](https://github.com/Troshchk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Troshchk/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/1a8a5cc49468f0df2bbe/maintainability)](https://codeclimate.com/github/Troshchk/python-project-49/maintainability)