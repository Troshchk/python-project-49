### Hexlet tests and linter status:
[![Actions Status](https://github.com/Troshchk/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Troshchk/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/1a8a5cc49468f0df2bbe/maintainability)](https://codeclimate.com/github/Troshchk/python-project-49/maintainability)

## Demo for the even game
<a href="https://asciinema.org/a/EUmWY7uViEVtzRCa2LROWAkaw" target="_blank"><img src="https://asciinema.org/a/EUmWY7uViEVtzRCa2LROWAkaw.svg" /></a>

## Demo for the calculator game
<a href="https://asciinema.org/a/OS8eBJN0xvobozmUYERSYKZAV" target="_blank"><img src="https://asciinema.org/a/OS8eBJN0xvobozmUYERSYKZAV.svg" /></a>