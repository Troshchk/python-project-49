#!/usr/bin/env python3

from ..games.gcd_module import play_gcd


def main():
    play_gcd()


if __name__ == "__main__":
    main()
