#!/usr/bin/env python3

from ..games.even_module import play_even_game


def main():
    play_even_game()


if __name__ == "__main__":
    main()
